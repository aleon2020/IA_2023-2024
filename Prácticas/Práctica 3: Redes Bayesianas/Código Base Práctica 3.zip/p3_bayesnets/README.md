# project-4-bayesnets
Bayes Net Inference Project for Spring 2021 CS188

A python3 (+ small modifications) version of https://github.com/BerkeleyAI/bayesNets2
